# Basic Linux Command Documentation

![ss1](ss/Screenshot2024-08-10at5.47.33PM.png)

## 1. `pwd` - Print Working Directory

- **Usage**: `pwd`
- **Description**: Prints the full path of the current working directory.
- **Examples**:
  - `pwd` - Displays the current directory path.

## 2. `ls` - List Directory Contents

- **Usage**: `ls [options] [directory]`
- **Description**: Lists the files and directories in the specified directory.
- **Examples**:
  - `ls` - Lists files and directories in the current directory.
  - `ls -l` - Lists files and directories in long format (detailed view).
  - `ls -a` - Lists all files, including hidden ones.

### `ls -l | wc -l` - Count Files and Directories

- **Usage**: `ls -l | wc -l`
- **Description**: Lists all files and directories in long format and counts the number of lines in the output. This effectively counts the number of files and directories in the current directory, including the "total" line.
- **Examples**:
  - `ls -l | wc -l` - Outputs the number of lines, which corresponds to the number of files and directories plus one for the "total" line.

## 3. `touch` - Create Empty Files

- **Usage**: `touch [options] file`
- **Description**: Updates the access and modification times of the specified file. If the file does not exist, it is created as an empty file.
- **Examples**:
  - `touch file.txt` - Creates `file.txt` if it does not exist.
  - `touch -c file.txt` - Does not create `file.txt` if it does not exist.

## 4. `mkdir` - Make Directory

- **Usage**: `mkdir [options] directory_name`
- **Description**: Creates a new directory with the specified name.
- **Examples**:
  - `mkdir new_folder` - Creates a directory named `new_folder`.

## 5. `cd` - Change Directory

- **Usage**: `cd [directory]`
- **Description**: Changes the current working directory to the specified directory.
- **Examples**:
  - `cd /home/user` - Changes to the `/home/user` directory.
  - `cd ..` - Moves up one directory level.
  - `cd ~` - Changes to the home directory.

## 6. `nano` - Command-Line Text Editor

- **Usage**: `nano [options] file`
- **Description**: Opens `file` in the Nano text editor for editing.
- **Examples**:
  - `nano file.txt` - Opens `file.txt` for editing.

## 7. `cat` - Concatenate and Display Files

- **Usage**: `cat [options] file`
- **Description**: Displays the contents of a file.
- **Examples**:
  - `cat file.txt` - Displays the content of `file.txt`.
  - `cat file1.txt file2.txt` - Concatenates and displays the contents of both files.

## 8. `mv` - Move or Rename Files or Directories

- **Usage**: `mv [options] source destination`
- **Description**: Moves or renames files or directories.
- **Examples**:
  - `mv old_name.txt new_name.txt` - Renames `old_name.txt` to `new_name.txt`.
  - `mv file.txt /path/to/destination/` - Moves `file.txt` to the specified directory.
  - `mv file1.txt file2.txt file3.txt /path/to/destination/` - Moves `file1.txt` `file2.txt` `file3.txt` to the specified directory.

![ss2](ss/Screenshot2024-08-10at5.47.43 PM.png)

## 9. `cp` - Copy Files or Directories

- **Usage**: `cp [options] source destination`
- **Description**: Copies files or directories from the source to the destination.
- **Examples**:
  - `cp file.txt copy_of_file.txt` - Copies `file.txt` to `copy_of_file.txt`.

![ss3](ss/Screenshot2024-08-10at5.52.23PM.png)

## 10. `rm` - Remove Files or Directories

- **Usage**: `rm [options] file_or_directory`
- **Description**: Removes files or directories.
- **Examples**:
  - `rm file.txt` - Deletes the file named `file.txt`.
  - `rm -r directory_name` - Recursively deletes the directory and its contents.
  - `rm -f file.txt` - Forces the deletion of `file.txt` without prompting.
  - `rm -rf file.txt` - Forces the deletion of folder and its content without prompting.

![ss4](ss/Screenshot2024-08-10at6.12.12PM.png)

## 11. `chmod` - Change File Mode (Permissions)

- **Usage**: `chmod [options] mode file`
- **Description**: Changes the access permissions of the specified file or directory.
- **Examples**:
  - `chmod 755 script.sh` - Sets the file `script.sh` to be executable by the owner and readable/executable by others.
  - `chmod u+x file.txt` - Adds execute permission to the owner of `file.txt`.
  - `chmod -R 644 /path/to/directory` - Recursively sets all files in the directory to be readable and writable by the owner, and readable by others.

## 12. `./` - Execute a File in the Current Directory

- **Usage**: `./filename`
- **Description**: Tells the shell to execute a file or script located in the current directory. This is commonly used for running executable scripts or binaries that are not in your system's `PATH`.
- **Examples**:
  - `./script.sh` - Executes the `script.sh` file located in the current directory.
  - `./program` - Runs the executable file named `program` in the current directory.

![ss6](ss/Screenshot2024-08-10at6.18.35PM.png)

![ss7](ss/Screenshot2024-08-10at6.26.25PM.png)
